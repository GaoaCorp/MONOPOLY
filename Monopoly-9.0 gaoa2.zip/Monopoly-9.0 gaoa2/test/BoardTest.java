/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Lusbin
 */
public class BoardTest {
    
    public BoardTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getSquare method, of class Board.
     */
    @Test
    public void testGetSquare() {
        System.out.println("getSquare");

        Board board = new Board();
        int num = 0;
        Squares result = board.getSquare(num);
        Board expResult = new Board(); 
        assertEquals(expResult, result);
    }

  @Test
    public void testGetSquareName() {
        System.out.println("getSquareName");
        Board board = new Board();
        int num = 0;
        String result = board.getSquareName(num);
        String expResult = "ExpectedSquareName";
        assertEquals(expResult, result);
    }

    /**
     * Test of doAction method, of class Board.


    /**
     * Test of getAllSquare method, of class Board.
     */
public void testGetAllSquare() {
        System.out.println("getAllSquare");
        Board board = new Board();
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        board.getAllSquare();
        System.setOut(System.out);
        String expectedSquareInfo = "expectedSquareInfo";
        assertTrue(outContent.toString().contains(expectedSquareInfo));

    }
    
}
